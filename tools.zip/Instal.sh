z="
";Fz='onXM';Oz='ore ';Ez='Rebr';Cz='edit';Mz='Mtk"';Pz='http';Hz=' "Te';Tz='Mtk';Lz='ronX';Gz='tk"';Rz='t.me';Jz='am: ';Qz='s://';Sz='/Reb';Bz=' "Cr';Dz='s: @';Kz='@Reb';Az='echo';Nz='expl';Iz='legr';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$z$Az$Hz$Iz$Jz$Kz$Lz$Mz$z$Nz$Oz$Pz$Qz$Rz$Sz$Lz$Tz"